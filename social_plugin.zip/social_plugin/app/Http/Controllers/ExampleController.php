<?php

namespace App\Http\Controllers;

class ExampleController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function index()
    {
		echo '<pre>';
		print_r([config('services.github.redirect')]);
		echo '</pre>';
		exit;

        echo 'test';
    }

    //
}
